# Perturbation Log

---

## System 1 — Validated, Routed Policy Pipeline

**Change made:** Triggered a `missing_source` failure by running the test that simulates a required field being absent from the document.

**Command:**
```
.venv/bin/pytest tests/test_us01_retry.py::test_ac_01_04_missing_source_halts_immediately -v -s
```

**Artifact:** `perturbation-policy-new.txt`

**Result on perturbed input:**
```
1 passed in 0.04s
```
The system made exactly **1 API call** and immediately escalated — no retries. The test name `test_ac_01_04_missing_source_halts_immediately` confirms the design: `missing_source` is classified as a futile error category and halts without retrying.

**Contrast with unperturbed input:**
On a well-formed document, the extractor succeeds on the first call and routes to `auto_approve` (as shown in `routing-output.txt` for POL-A: `"decision": "auto_approve"`). On a document with a recoverable format error, the system retries with error feedback appended. On a `missing_source` case, the system escalates immediately with zero retries — the document literally lacks the required field and no amount of reprompting will produce information that was never in the source.

---

## System 2 — Schema-Enforced Mortgage Extraction

**Change made:** Ran the extractor against `income_sum_mismatch.txt`, a document where the declared monthly total does not match the sum of income components.

**Command:**
```
.venv/bin/pytest tests/test_us04_validator.py::test_ac_04_04_real_paystub_with_sum_mismatch_is_flagged -v -s
```

**Artifact:** `perturbation-mortgage-new.txt`

**Result on perturbed input:**
```
1 passed in 1.63s
```
The validator flagged the discrepancy. From `run-mortgage-mismatch.txt`:
```json
"validation": {
    "consistent": false,
    "discrepancies": [
      {
        "field": "total_monthly_income",
        "calculated": 9642.17,
        "stated": 10892.17,
        "delta": -1250.0
      }
    ]
  }
```
The sum of components (base + bonus + commission + overtime + other = 9642.17) does not match the stated total (10892.17), a delta of -1250.00.

**Contrast with unperturbed input:**
On `appraisal_informal_sqft.txt` (clean document), the validator returns `"consistent": true` with `"discrepancies": []` (shown in `run-mortgage-appraisal.txt`). The perturbed document triggers `"consistent": false` and surfaces the exact field, calculated value, stated value, and delta.

---

## System 3 — Multi-Source Supply Chain Synthesis

**Change made:** Ran the coordinator with `--simulate-timeout` to force the logistics source to fail mid-run.

**Command:**
```
.venv/bin/supply-chain-investigate meridian --offline --simulate-timeout
```

**Artifact:** `run-supply-timeout.txt`

**Result on perturbed input:**
```
> Sources unavailable: logistics unavailable (timeout)

## Incomplete
### late_shipment_count  [missing source: timeout reading logistics]
- missing source: timeout reading logistics
```
The run completed successfully despite the source failure. The `on_time_delivery_rate` moved from **Contested** (two conflicting values) to **Well-Established** (single source only, 95% from supplier_audit), and `late_shipment_count` moved to **Incomplete** with explicit annotation.

**Contrast with unperturbed input:**
Without `--simulate-timeout` (`run-supply.txt`), the logistics source is available and `on_time_delivery_rate` appears in **Contested** with both values:
- 95.0% — supplier_audit (2026-04-10)
- 78.0% — logistics (2026-04-05)

With timeout, the conflict disappears (logistics data is lost) and `late_shipment_count` is annotated as unreachable rather than omitted silently. The coordinator did not abort — confirmed by `perturbation-supply-new.txt` (`test_single_failure_does_not_abort`: 1 passed).
