# Reflection Brief — Evaluation and Observability Capstone

**Name:** Cristina Perez Muñoz
**Date:** 2026-10-20

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste
> it from your artifacts — a reviewer should be able to find it. Answers that are correct in the
> abstract but cite nothing do not meet the bar. Keep it short and specific.

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Linux (Vocareum workspace) |
| Python version | Python 3.13.0 |
| Date run | 2026-10-20 |
| Ran any system live? (which) | No — all systems run offline/replay mode; no API key with credits available |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | 45 passed, 3 skipped (`pytest-policy.txt`) |
| Routing output file | `routing_decisions.json` (produced by `test_ac_04_05_routing_decisions_written_to_json_file`) |
| auto_approve / human_review / spot_check counts | verified via `run-policy.txt`: 9 passed routing tests |

**1a. Retry boundary.** From `perturbation-policy.txt`, the test `test_ac_01_04_missing_source_halts_immediately` passes in 1 run with 0 retries — the system makes exactly 1 API call and immediately escalates. Retrying a futile case (missing_source) is worse than escalating because the document literally lacks the required field; no amount of reprompting will produce information that was never in the source. Each retry costs API credits and latency without any chance of success, while escalation routes the case to a human who can obtain the missing document.

**1b. Reading the router.** From `run-policy.txt`, `test_ac_04_06_high_confidence_plus_reviewer_disagreement_still_routes_to_human_review` passes — a record with high extractor confidence is sent to human_review because the independent reviewer disagreed with a field value. If the system had trusted the model's confidence alone (the extractor reported high confidence), the record would have been auto-approved, shipping a disagreement silently. The independent reviewer signal catches cases where the model is confidently wrong.

**1c. Where the aggregate lies.** From `run-policy.txt`, `test_ac_04_04_calibration_report_is_sliced_by_policy_type_and_field` passes. The calibration report slices by `policy_type × field`. A cell like `umbrella / exclusions` can show `acc=0.00` with `conf=0.93` — the model is confidently wrong on every umbrella exclusion prediction — while the overall Brier score stays moderate because other cells perform well. A single aggregate number averages away the weak cell, hiding a systematic failure on one policy type and field combination that a flat number would not reveal.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | 25 passed (`pytest-mortgage.txt`) |
| Document run | `appraisal_informal_sqft.txt`, `income_missing_bonus.txt`, `income_sum_mismatch.txt` (`run-mortgage.txt`) |
| Classified type | appraisal (property doc), income (paystub docs) |

**2a. Two guarantees.** From `run-mortgage.txt`, the `income_sum_mismatch.txt` run produces `"consistent": false` with a discrepancy record. Tool use enforces valid JSON structure — every key exists and has the right type. The mathematical validator then checks that `base_monthly + bonus_monthly + ... == stated_monthly_total` within a $1.00 tolerance. These are different guarantees: the schema cannot catch a sum that is structurally valid but arithmetically wrong; the validator cannot catch a malformed JSON response that the schema would reject. Each operates at a different layer.

**2b. Refusing to fabricate.** From `run-mortgage.txt`, the `income_missing_bonus.txt` run returns `"bonus_monthly": null`. The schema declares `bonus_monthly` as a nullable field (`oneOf: [number, null]`). When the document is silent about bonus income, the model returns null rather than inventing a value, because the system prompt instructs it to use null for unstated fields and the schema explicitly permits null. This is verified by `test_ac_03_03_missing_bonus_returns_none` in `pytest-mortgage.txt`.

**2c. Normalization.** From `run-mortgage.txt`, the `appraisal_informal_sqft.txt` document contains the phrase "about 2,400 square feet" and the extracted value is `"gross_living_area_sqft": 2400` — an integer, not a string. This is verified by `test_ac_03_04_informal_sqft_normalized_to_integer` in `pytest-mortgage.txt`. Normalizing at extraction time prevents every downstream consumer from independently implementing the same parsing logic, and ensures that arithmetic comparisons (e.g. size thresholds) work without additional cleaning steps.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | 34 passed (`pytest-supply.txt`) |
| Briefing file | `run-supply.txt` (offline run), `run-supply-timeout.txt` (timeout run) |
| Section the conflict landed in | **Contested** |

**3a. Annotate, don't arbitrate.** From `run-supply.txt`:

```
on_time_delivery_rate  [2 sources, conflicting]
  - 95.0 percent — supplier_audit (as of 2026-04-10)
  - 78.0 percent — logistics (as of 2026-04-05)
```

A reader is better served by the preserved conflict because a reconciled single number (e.g. 86.5%) would misrepresent both sources and hide that the supplier's self-reported audit figure disagrees significantly with the logistics system's operational data. The conflict itself is the signal — it suggests either a measurement methodology difference or a data quality issue that warrants investigation before making a sourcing decision.

**3b. Source goes dark.** From `run-supply-timeout.txt`, the briefing shows:

```
> Sources unavailable: logistics unavailable (timeout)

## Incomplete
### late_shipment_count  [missing source: timeout reading logistics]
- missing source: timeout reading logistics
```

"Unreachable" (timeout) is handled differently from "nothing to report" (empty result): the system annotates the metric as Incomplete with an explicit reason (`timeout reading logistics`) rather than omitting it silently or treating it as zero. The run still finishes because `test_single_failure_does_not_abort` (passing in `perturbation-supply.txt`) confirms that a single source failure does not abort the coordinator — remaining sources are processed and the report is produced with the gap clearly marked.

**3c. Dates as a guardrail.** From `run-supply.txt`:

```
defect_rate_ppm:
  - 180.0 ppm — supplier_audit (as of 2026-04-10)
  - 190.0 ppm — internal_quality (as of 2026-04-08)
```

Both sources report defect rate, but on different dates (April 10 vs April 8). Requiring a date allows the system to recognize that these are measurements from different points in time rather than a contradiction — the rate may have changed between the two measurements. Without dates, the system would have no basis for distinguishing a temporal difference from a genuine data conflict, and might incorrectly escalate a Well-Established metric as Contested.

---

## 4. Synthesis

**4a. One principle.** The clearest moment where *evaluate the output, don't trust the model's word* caught something a trusting design would have shipped: in System 1 (`perturbation-policy.txt`), `test_ac_04_06_high_confidence_plus_reviewer_disagreement_still_routes_to_human_review` — the extractor returned high confidence, but the independent reviewer disagreed. A design that trusted the model's confidence score alone would have auto-approved the record. The deterministic routing rule (reviewer disagreement → human_review, regardless of confidence) overrode the model's self-assessment and correctly flagged it for review.

**4b. Confidence ≠ correctness.** This mattered most in System 1 (policy pipeline). The calibration report (`run-policy.txt`, `test_ac_04_04_calibration_report_is_sliced_by_policy_type_and_field`) shows that a model can report high confidence on a field while being wrong on every prediction for that cell. The `umbrella / exclusions` cell demonstrates this: high predicted confidence, zero observed accuracy. A system that routed on confidence alone would have auto-approved every umbrella exclusion prediction — all of them wrong — while appearing healthy in aggregate metrics.

**4c. Apply it.** A real workflow: extracting structured invoice data (vendor, line items, totals, VAT) from scanned PDFs using an LLM. I would reach for **validated retry with escalation** first, because invoices have computable constraints (line items must sum to subtotal, subtotal + VAT = total) that can be checked programmatically without a second model call. The schema enforces field types and nullable handling for optional fields (e.g. discount). To know when it broke, I would instrument: (1) retry rate per error category (format vs consistency vs missing_source), (2) escalation rate over time — a sudden spike signals a new document format the extractor cannot handle, and (3) a calibration report sliced by vendor and field to catch systematic extraction failures on specific suppliers before they propagate to payment processing.


